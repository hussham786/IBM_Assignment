package com.ibm.mra.exceptions;

public class MyException extends Exception {
		public MyException(String str) {
			super(str);
	}

}
